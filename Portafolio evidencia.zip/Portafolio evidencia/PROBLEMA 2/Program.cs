﻿using System;

namespace Lab7__1065221
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            int numeroseleccionado = 0;
            int numerousuario = 0;
            int[] numeros = new int[5];
            while (opcion < 4)
            {
                Console.WriteLine("1. definir numero de pool");
                Console.WriteLine("2. adivina el numero");
                Console.WriteLine("3. imprimir pool");
                    Console.WriteLine("4. Salir");
                opcion = Int32.Parse(Console.ReadLine());

                if (opcion == 1)
                {
                    
                    numeros[0] = 10;
                    numeros[1] = 50;
                    numeros[2] = 3;
                    numeros[3] = 1;
                    numeros[4] = 5;


                    Random rnd = new Random();
                    int indiceSeleccionado = rnd.Next(0, 4);
                    numeroseleccionado = numeros[indiceSeleccionado];


                    Console.WriteLine(" El valor seleccionado al azar fue 1" + numeroseleccionado );



                }
                 
                if (opcion == 2)
                {
                    Console.WriteLine("Por favor ingrese un numero :");
                    numerousuario = Int32.Parse(Console.ReadLine());


                    if (numerousuario == numeroseleccionado )
                    {
                        Console.WriteLine("Felicidades usted adivino el numero");
                    }
                    else
                    {
                        Console.WriteLine("El numero es incorrecto");
                        if(numerousuario > numeroseleccionado )
                        {
                            Console.WriteLine("El numero es menor " + numerousuario);
                        }
                        else
                        {
                            Console.WriteLine("El numero correcto es igual o mayor" + numerousuario);
                        }
                        if (opcion == 3)
                        {
                            int contador = 0; 
                            while (contador <=4)

                            {
                                Console.WriteLine(numeros[contador]);
                                contador = contador + 1;
                            }
                            
                        }
                    }
                }


                
            }
            
        }
    }
}
